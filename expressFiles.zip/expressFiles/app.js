const express = require("express");
const app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);

// app.get('/', (req, res)=>{
//     res.send("Rohan's server");
// })

app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
  });
  
  io.on('connection', function(socket){
    console.log('a user connected');
    socket.on('msg', function(msg, username){
        io.emit('message', msg, username);
      });
    
  });
  
  http.listen(3000, function(){
    console.log('listening on port :-: 3000');
  });